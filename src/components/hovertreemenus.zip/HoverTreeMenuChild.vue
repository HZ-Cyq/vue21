<template>
    <ul class="menu-root" v-if="nodes && nodes.length">
      <li
        v-for="(node, index) in nodes"
        :key="index"
        class="menu-item"
        @mouseenter="hovered = node"
        @mouseleave="hovered = null"
      >
        <div class="label" @click="handleClick(node)">
          {{ node.title }}
          <span v-if="node.subMenu && node.subMenu.length"> ▶ </span>
        </div>
  
        <!-- 子菜单，最多三层 -->
        <ul 
          v-if="hovered === node && node.subMenu && node.subMenu.length"
          class="menu-root submenu"
        >
          <li
            v-for="(childNode, childIndex) in node.subMenu"
            :key="childIndex"
            class="menu-item"
            @mouseenter="childHovered = childNode"
            @mouseleave="childHovered = null"
          >
            <div class="label" @click="handleClick(childNode)">
              {{ childNode.title }}
              <span v-if="childNode.subMenu && childNode.subMenu.length"> ▶ </span>
            </div>
            
            <!-- 第三层菜单 -->
            <ul 
              v-if="childHovered === childNode && childNode.subMenu && childNode.subMenu.length"
              class="menu-root submenu-level3"
            >
              <li
                v-for="(grandChildNode, grandChildIndex) in childNode.subMenu"
                :key="grandChildIndex"
                class="menu-item"
              >
                <div class="label" @click="handleClick(grandChildNode)">
                  {{ grandChildNode.title }}
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </li>
    </ul>
  </template>
  
  <script>
  export default {
    name: "HoverTreeMenuChild",
    props: {
      nodes: {
        type: Array,
        required: true,
      },
    },
    data() {
      return {
        hovered: null,
        childHovered: null
      };
    },
    methods: {
      handleClick(node) {
        if (!node.subMenu || node.subMenu.length === 0) {
          if (node.componentName) {
            this.$emit("component-selected", node.componentName);
          } else {
            alert("无 componentName：" + node.title);
          }
        }
      },
    }
  };
  </script>
  
  <style scoped>
  .menu-root {
    list-style: none;
    padding: 0;
    margin: 0;
    background: #34495e;
    color: white;
    display: inline-block;
    white-space: nowrap;
    position: relative;
    min-width: 100px;
    max-width: 400px;
    font-size: 14px;
  }
  
  .menu-item {
    position: relative;
  }
  
  .label {
    padding: 10px 15px;
    cursor: pointer;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: block;
  }
  
  .label:hover {
    background-color: #2c3e50;
  }
  
  .submenu {
    position: absolute;
    top: 0;
    left: 100%;
    background: #34495e;
    white-space: nowrap;
    min-width: 100px;
    max-width: 400px;
    display: block;
    overflow-x: auto;
    word-break: break-all;
  }
  
  .submenu-level3 {
    position: absolute;
    top: 0;
    left: 100%;
    background: #34495e;
    white-space: nowrap;
    min-width: 100px;
    max-width: 400px;
    display: block;
    overflow-x: auto;
    word-break: break-all;
  }
  </style>