<template>
    <div class="test-menu">
      <h3>测试菜单</h3>
      <hover-tree-menu :nodes="testData" @component-selected="onComponentSelected" />
    </div>
  </template>
  
  <script>
  import HoverTreeMenu from '@/components/hovertreemenus/HoverTreeMenu.vue';
  
  export default {
    components: {
      HoverTreeMenu
    },
    data() {
      return {
        testData: [
          {
            title: "测试菜单",
            subMenu: [
              { title: "选项1", componentName: "DemoComponent1" },
              { title: "选项2", componentName: "DemoComponent2" },
            ],
          }
        ]
      }
    },
    methods: {
      onComponentSelected(name) {
        console.log("选中组件:", name);
      }
    }
  }
  </script>